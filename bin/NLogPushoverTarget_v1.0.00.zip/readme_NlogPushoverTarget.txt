NLogPushoverTarget
A custom target for sending NLog logs as notifications to Pushover (https://pushover.net)

by Martin Gadd

This package can be used to let Nlog send notifications to Pushover

Third Party Dlls

pushover.dll comes from Pushover.NET at https://pushover.codeplex.com/ 
NLog.dll comes from NLog at https://github.com/NLog/NLog

Installation STEPS:

Create a Pushover account (https://pushover.net)
Install Pushover on your phone
Create a new application at your Pushover account
Extract the includes dlls in the same directory as your NLog.dll
Edit the Pushover target with at least your user key (from Step 1.) and application Key (Step 3.)
Test by letting your application create an Logging event.
Should you experience errors; logging is made to NLog's internal logger (https://github.com/NLog/NLog/wiki/Internal-Logging)

Change history:
Version 1.0.0
------------------------------------------------------------------------
- Initial Release
- Target support following parameters
	- 	ApplicationKey
	-	UserKey
	- 	NotificationTitlePrefix (optional, Defaults to "NLog")
		Notfication title renders as "NotificationTitlePrefix :[${Level}] ${timestamp}"
	- 	layout (optional, Defaults to Nlog default)
------------------------------------------------------------------------

		


